GPNet — casetable.tsx Update
---------------------------------
1. In Replit, open the Files panel.
2. Navigate to: client/src/components/
3. Delete the existing casetable.tsx (if present).
4. Upload or drag this new casetable.tsx file.
5. Click Run or Preview.
6. You should now see:
   - A new "Date of Injury" column.
   - A clickable "View Certificate" link opening the PDF in a new tab.
7. Commit to GitHub if desired:
   git add .
   git commit -m "Add Date of Injury column and clickable Certificate link"
   git push origin main

import * as React from "react";

type Worker = {
  id: string | number;
  workerName?: string;
  companyName?: string;
  custom_fields?: {
    cf_injury_date?: string;
    cf_url?: string;
  };
};

type Props = {
  workers: Worker[];
};

function formatDate(raw?: string): string {
  if (!raw) return "—";
  const d = new Date(raw);
  if (isNaN(d.getTime())) return raw;
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

export default function WorkerTable({ workers }: Props) {
  return (
    <div className="relative w-full overflow-auto">
      <table className="w-full caption-bottom text-sm">
        <thead className="[&_tr]:border-b">
          <tr>
            <th className="px-3 py-2 text-left font-medium">Worker</th>
            <th className="px-3 py-2 text-left font-medium">Company</th>
            <th className="px-3 py-2 text-left font-medium">Date of Injury</th>
            <th className="px-3 py-2 text-left font-medium">Certificate</th>
          </tr>
        </thead>
        <tbody className="[&_tr:last-child]:border-0">
          {workers?.length ? (
            workers.map((w) => (
              <tr key={String(w.id)} className="border-b">
                <td className="px-3 py-2">{w.workerName || "—"}</td>
                <td className="px-3 py-2">{w.companyName || "—"}</td>
                <td className="px-3 py-2">
                  {formatDate(w.custom_fields?.cf_injury_date)}
                </td>
                <td className="px-3 py-2">
                  {w.custom_fields?.cf_url ? (
                    <a
                      href={w.custom_fields.cf_url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-blue-600 underline underline-offset-2 hover:opacity-80"
                    >
                      View Certificate
                    </a>
                  ) : (
                    "—"
                  )}
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td
                className="px-3 py-4 text-center text-muted-foreground"
                colSpan={4}
              >
                No workers found.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
}
